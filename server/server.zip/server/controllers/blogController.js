const Blog = require("../models/blog.js");
const userController={
    userHome:(req,res)=>{
        res.render("home");
    },
    
    
}

    

module.exports=blogController;
